﻿using UnityEngine;

public class Movement : MonoBehaviour {

	Touch firstTouch;

	void Update () {
		if (Input.touchCount > 0) {
			Touch touch = Input.GetTouch (0);
			if (touch.phase == TouchPhase.Began)
				firstTouch = touch;
			else if (touch.phase == TouchPhase.Moved) {
				Vector2 delta = firstTouch.position - touch.position;
				delta.Normalize ();
				//delta = camera.InverseTransformDirection (delta);
				transform.Rotate (delta * Time.deltaTime * 45);
			}
		}
	}
}
